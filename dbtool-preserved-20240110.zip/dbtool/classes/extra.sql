alter table IVR_PROCESS modify column CREATETIME DATE
alter table IVR_PROCESS modify column UPDATETIME DATE
alter table IVR_PROCESS modify column PROCESS_STRING LONGTEXT
alter table SYS_NOTIFICATION modify column CONTENT varchar(512)
alter table AUTH_PERM_CATE modify column NAME varchar(64)